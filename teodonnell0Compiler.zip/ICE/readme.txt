Files in this directory

<backup>               ... directory for backing up java source code
msetup.bat             ... run this batch file to set environment variables
savit.bat              ... run this to back up java source code
mini.java              ... source code for mini assembler
mini.class             ... mini-assembler, java executable
mice.java              ... source code for mICE virtual machine
mice.class             ... mICE virtual machine, java executable
TextReader.class       ... support routines needed for reading text files
deice.java             ... source code for ICE dis-assembler
deice.class            ... ICE dis-assembler, java executable
b.asm                  ... demo assembly code, simple program
c.asm                  ... demo assembly code, compares and jumps
iotest.asm             ... demo assembly code, i/o modes and string i/o


